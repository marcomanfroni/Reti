# -*- coding: utf-8 -*-
"""
Progetto Programmazione di Reti
Traccia n. 3 - Web Server Agenzia Viaggi
Manfroni Marco - matricola 0900064991

"""

import http.server
import base64
import socketserver
import sys, signal
import json

#classe per la gestione dell'autenticazione
class CustomServerHandler(http.server.SimpleHTTPRequestHandler):

    def do_AUTHHEAD(self):
        self.send_response(401)
        self.send_header(
            'WWW-Authenticate', 'Basic realm="Giramondo"')
        self.send_header('Content-type', 'text/html')
        self.end_headers()

    def do_GET(self):
        key = self.server.get_auth_key()
        if self.headers.get('Authorization') == None:
            self.do_AUTHHEAD()
            response = {
                'success': False,
                'error': 'No auth header received'
            }

            self.wfile.write(bytes(json.dumps(response), 'utf-8'))
    
        elif self.headers.get('Authorization') == 'Basic ' + str(key):
            http.server.SimpleHTTPRequestHandler.do_GET(self)
        else:
            self.do_AUTHHEAD()
            response = {
                'success': False,
                'error': 'Invalid credentials'
            }
            self.wfile.write(bytes(json.dumps(response), 'utf-8'))
            
#nuova classe per gestire multithread e autenticazione
class CustomHTTPServer(socketserver.ThreadingTCPServer):
    key = ''
#funzione di inizializzazione
    def __init__(self, address, handlerClass=CustomServerHandler):
        super().__init__(address, handlerClass)
#funzione per settare le credenziali di accesso necessarie
    def set_auth(self, username, password):
        self.key = base64.b64encode(
            bytes('%s:%s' % (username, password), 'utf-8')).decode('ascii')
#funzione per recuperare le credenziali inserite
    def get_auth_key(self):
        return self.key
    
# Legge il numero della porta dalla riga di comando
if sys.argv[1:]:
  port = int(sys.argv[1])
else:
  port = 8080
  
server = CustomHTTPServer(('',port))
server.set_auth('usr', 'pswd')
#Assicura che da tastiera usando la combinazione
#di tasti Ctrl-C termini in modo pulito tutti i thread generati
server.daemon_threads = True  
#il Server acconsente al riutilizzo del socket anche se ancora non Ã¨ stato
#rilasciato quello precedente, andandolo a sovrascrivere
server.allow_reuse_address = True  


def signal_handler(signal, frame):
    print( 'Exiting http server (Ctrl+C pressed)')
    try:
        if( server ):
             server.server_close()
    finally:
        sys.exit(0)

#interrompe lâesecuzione se da tastiera arriva la sequenza (CTRL + C) 
signal.signal(signal.SIGINT, signal_handler)

# entra nel loop infinito
try:
    while True:
        #sys.stdout.flush()
        server.serve_forever()
except KeyboardInterrupt:
    pass

server.server_close()
